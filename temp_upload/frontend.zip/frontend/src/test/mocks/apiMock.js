import { vi } from "vitest";

vi.mock("../../api", () => ({

    getResults: vi.fn(() =>
        Promise.resolve({
            success: true,
            data: {}
        })
    ),

    getGraphResults: vi.fn(() =>
        Promise.resolve({
            success: true,
            graphs: []
        })
    ),

    getLedgers: vi.fn(() =>
        Promise.resolve({
            success: true,
            ledgers: []
        })
    ),

    getPatients: vi.fn(() =>
        Promise.resolve({
            success: true,
            patients: []
        })
    ),

    getPatientCards: vi.fn(() =>
        Promise.resolve({
            success: true,
            patients: []
        })
    ),

    getProgressLogs: vi.fn(() =>
        Promise.resolve({
            success: true,
            logs: []
        })
    ),

    getPipelineStatus: vi.fn(() =>
        Promise.resolve({
            running: false
        })
    )
}));