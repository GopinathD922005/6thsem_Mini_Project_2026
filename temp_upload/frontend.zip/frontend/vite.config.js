import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({

    plugins: [react()],

    server: {

        port: 5173,

        proxy: {

            "/upload": {

                target: "http://127.0.0.1:8000",

                changeOrigin: true
            },

            "/run": {

                target: "http://127.0.0.1:8000",

                changeOrigin: true
            },

            "/results": {

                target: "http://127.0.0.1:8000",

                changeOrigin: true
            }
        }
    },

    test: {

        environment: "jsdom",

        setupFiles: "./src/test/setup.js",

        globals: true
    }
});